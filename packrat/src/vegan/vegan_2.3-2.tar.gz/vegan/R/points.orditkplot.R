`points.orditkplot` <-
    function(x, ...)
{
    points(x$points, ...)
}

