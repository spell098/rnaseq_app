## "new" permutation code was moved to package 'permute' in R 2.0-0.
## Here we list as defunct those functions that are not in 'permute'.

`metaMDSrotate` <-
    function(object, vec, na.rm = FALSE, ...)
{
    .Defunct(new="MDSrotate", "vegan")
}
