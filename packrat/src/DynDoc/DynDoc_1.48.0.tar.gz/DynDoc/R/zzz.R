.onLoad <- function(pkgname, libname) require("methods")
