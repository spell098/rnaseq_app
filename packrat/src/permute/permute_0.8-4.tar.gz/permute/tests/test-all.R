## Test `permute` using the `testthat` package

## Setup
library("testthat")
library("permute")

## Runs the tests in inst/tests
test_check("permute")
