#ifndef lint
static const char htmlsccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif

#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYPATCH 20140101

#define YYEMPTY        (-1)
#define htmlclearin      (htmlchar = YYEMPTY)
#define htmlerrok        (htmlerrflag = 0)
#define YYRECOVERING() (htmlerrflag != 0)

#define YYPREFIX "html"

#define YYPURE 0

#line 15 "../../lib/common/htmlparse.y"

#include "render.h"
#include "htmltable.h"
#include "htmllex.h"

extern int htmlparse(void);

typedef struct sfont_t {
    htmlfont_t *cfont;	
    struct sfont_t *pfont;
} sfont_t;

static struct {
  htmllabel_t* lbl;       /* Generated label */
  htmltbl_t*   tblstack;  /* Stack of tables maintained during parsing */
  Dt_t*        fitemList; /* Dictionary for font text items */
  Dt_t*        fparaList; 
  agxbuf*      str;       /* Buffer for text */
  sfont_t*     fontstack;
} HTMLstate;

/* free_ritem:
 * Free row. This closes and frees row's list, then
 * the pitem itself is freed.
 */
static void
free_ritem(Dt_t* d, pitem* p,Dtdisc_t* ds)
{
  dtclose (p->u.rp);
  free (p);
}

/* free_item:
 * Generic Dt free. Only frees container, assuming contents
 * have been copied elsewhere.
 */
static void
free_item(Dt_t* d, void* p,Dtdisc_t* ds)
{
  free (p);
}

/* cleanTbl:
 * Clean up table if error in parsing.
 */
static void
cleanTbl (htmltbl_t* tp)
{
  dtclose (tp->u.p.rows);
  free_html_data (&tp->data);
  free (tp);
}

/* cleanCell:
 * Clean up cell if error in parsing.
 */
static void
cleanCell (htmlcell_t* cp)
{
  if (cp->child.kind == HTML_TBL) cleanTbl (cp->child.u.tbl);
  else if (cp->child.kind == HTML_TEXT) free_html_text (cp->child.u.txt);
  free_html_data (&cp->data);
  free (cp);
}

/* free_citem:
 * Free cell item during parsing. This frees cell and pitem.
 */
static void
free_citem(Dt_t* d, pitem* p,Dtdisc_t* ds)
{
  cleanCell (p->u.cp);
  free (p);
}

static Dtdisc_t rowDisc = {
    offsetof(pitem,u),
    sizeof(void*),
    offsetof(pitem,link),
    NIL(Dtmake_f),
    (Dtfree_f)free_ritem,
    NIL(Dtcompar_f),
    NIL(Dthash_f),
    NIL(Dtmemory_f),
    NIL(Dtevent_f)
};
static Dtdisc_t cellDisc = {
    offsetof(pitem,u),
    sizeof(void*),
    offsetof(pitem,link),
    NIL(Dtmake_f),
    (Dtfree_f)free_item,
    NIL(Dtcompar_f),
    NIL(Dthash_f),
    NIL(Dtmemory_f),
    NIL(Dtevent_f)
};

typedef struct {
    Dtlink_t    link;
    textpara_t  ti;
} fitem;

typedef struct {
    Dtlink_t     link;
    htextpara_t  lp;
} fpara;

static void 
free_fitem(Dt_t* d, fitem* p, Dtdisc_t* ds)
{
    if (p->ti.str)
	free (p->ti.str);
    if (p->ti.font)
        free_html_font (p->ti.font);
    free (p);
}

static void 
free_fpara(Dt_t* d, fpara* p, Dtdisc_t* ds)
{
    textpara_t* ti;

    if (p->lp.nitems) {
	int i;
	ti = p->lp.items;
	for (i = 0; i < p->lp.nitems; i++) {
	    if (ti->str) free (ti->str);
	    if (ti->font) free_html_font (ti->font);
	    ti++;
	}
	free (p->lp.items);
    }
    free (p);
}

static Dtdisc_t fstrDisc = {
    0,
    0,
    offsetof(fitem,link),
    NIL(Dtmake_f),
    (Dtfree_f)free_item,
    NIL(Dtcompar_f),
    NIL(Dthash_f),
    NIL(Dtmemory_f),
    NIL(Dtevent_f)
};


static Dtdisc_t fparaDisc = {
    0,
    0,
    offsetof(fpara,link),
    NIL(Dtmake_f),
    (Dtfree_f)free_item,
    NIL(Dtcompar_f),
    NIL(Dthash_f),
    NIL(Dtmemory_f),
    NIL(Dtevent_f)
};

/* dupFont:
 */
static htmlfont_t *
dupFont (htmlfont_t *f)
{
    if (f) f->cnt++;
    return f;
}

/* appendFItemList:
 * Append a new fitem to the list.
 */
static void
appendFItemList (agxbuf *ag)
{
    fitem *fi = NEW(fitem);

    fi->ti.str = strdup(agxbuse(ag));
    fi->ti.font = dupFont (HTMLstate.fontstack->cfont);
    dtinsert(HTMLstate.fitemList, fi);
}	

/* appendFLineList:
 */
static void 
appendFLineList (int v)
{
    int cnt;
    fpara *ln = NEW(fpara);
    fitem *fi;
    Dt_t *ilist = HTMLstate.fitemList;

    cnt = dtsize(ilist);
    ln->lp.nitems = cnt;
    ln->lp.just = v;
    if (cnt) {
        int i = 0;
	ln->lp.items = N_NEW(cnt, textpara_t);

	fi = (fitem*)dtflatten(ilist);
	for (; fi; fi = (fitem*)dtlink(fitemList,(Dtlink_t*)fi)) {
	    ln->lp.items[i] = fi->ti;
	    i++;
	}
    }

    dtclear(ilist);

    dtinsert(HTMLstate.fparaList, ln);
}

static htmltxt_t*
mkText(void)
{
    int cnt;
    Dt_t * ipara = HTMLstate.fparaList;
    fpara *fl ;
    htmltxt_t *hft = NEW(htmltxt_t);
    
    if (dtsize (HTMLstate.fitemList)) 
	appendFLineList (UNSET_ALIGN);

    cnt = dtsize(ipara);
    hft->nparas = cnt;
    	
    if (cnt) {
	int i = 0;
	hft->paras = N_NEW(cnt,htextpara_t);	
    	for(fl=(fpara *)dtfirst(ipara); fl; fl=(fpara *)dtnext(ipara,fl)) {
    	    hft->paras[i] = fl->lp;
    	    i++;
    	}
    }
    
    dtclear(ipara);

    return hft;
}

/* addRow:
 * Add new cell row to current table.
 */
static void addRow (void)
{
  Dt_t*      dp = dtopen(&cellDisc, Dtqueue);
  htmltbl_t* tbl = HTMLstate.tblstack;
  pitem*     sp = NEW(pitem);
  sp->u.rp = dp;
  dtinsert (tbl->u.p.rows, sp);
}

/* setCell:
 * Set cell body and type and attach to row
 */
static void setCell (htmlcell_t* cp, void* obj, int kind)
{
  pitem*     sp = NEW(pitem);
  htmltbl_t* tbl = HTMLstate.tblstack;
  pitem*     rp = (pitem*)dtlast (tbl->u.p.rows);
  Dt_t*      row = rp->u.rp;
  sp->u.cp = cp;
  dtinsert (row, sp);
  cp->child.kind = kind;
  
  if(kind == HTML_TEXT)
  	cp->child.u.txt = (htmltxt_t*)obj;
  else if (kind == HTML_IMAGE)
    cp->child.u.img = (htmlimg_t*)obj;
  else
    cp->child.u.tbl = (htmltbl_t*)obj;
}

/* mkLabel:
 * Create label, given body and type.
 */
static htmllabel_t* mkLabel (void* obj, int kind)
{
  htmllabel_t* lp = NEW(htmllabel_t);

  lp->kind = kind;
  if (kind == HTML_TEXT)
    lp->u.txt = (htmltxt_t*)obj;
  else
    lp->u.tbl = (htmltbl_t*)obj;
  return lp;
}

/* freeFontstack:
 * Free all stack items but the last, which is
 * put on artificially during in parseHTML.
 */
static void
freeFontstack(void)
{
    sfont_t* s;
    sfont_t* next;

    for (s = HTMLstate.fontstack; (next = s->pfont); s = next) {
	free_html_font (s->cfont);
	free(s);
    }
}

/* cleanup:
 * Called on error. Frees resources allocated during parsing.
 * This includes a label, plus a walk down the stack of
 * tables. Note that we use the free_citem function to actually
 * free cells.
 */
static void cleanup (void)
{
  htmltbl_t* tp = HTMLstate.tblstack;
  htmltbl_t* next;

  if (HTMLstate.lbl) {
    free_html_label (HTMLstate.lbl,1);
    HTMLstate.lbl = NULL;
  }
  cellDisc.freef = (Dtfree_f)free_citem;
  while (tp) {
    next = tp->u.p.prev;
    cleanTbl (tp);
    tp = next;
  }
  cellDisc.freef = (Dtfree_f)free_item;

  fstrDisc.freef = (Dtfree_f)free_fitem;
  dtclear (HTMLstate.fitemList);
  fstrDisc.freef = (Dtfree_f)free_item;

  fparaDisc.freef = (Dtfree_f)free_fpara;
  dtclear (HTMLstate.fparaList);
  fparaDisc.freef = (Dtfree_f)free_item;

  freeFontstack();
}

/* nonSpace:
 * Return 1 if s contains a non-space character.
 */
static int nonSpace (char* s)
{
  char   c;

  while ((c = *s++)) {
    if (c != ' ') return 1;
  }
  return 0;
}

/* pushFont:
 * Fonts are allocated in the lexer.
 */
static void
pushFont (htmlfont_t *f)
{
    sfont_t *ft = NEW(sfont_t);
    htmlfont_t* curfont = HTMLstate.fontstack->cfont;

    if (curfont) {
	if (!f->color && curfont->color)
	    f->color = strdup(curfont->color);
	if ((f->size < 0.0) && (curfont->size >= 0.0))
	    f->size = curfont->size;
	if (!f->name && curfont->name)
	    f->name = strdup(curfont->name);
	if (curfont->flags)
	    f->flags |= curfont->flags;
    }

    ft->cfont = dupFont (f);
    ft->pfont = HTMLstate.fontstack;
    HTMLstate.fontstack = ft;
}

/* popFont:
 */
static void 
popFont (void)
{
    sfont_t* curfont = HTMLstate.fontstack;
    sfont_t* prevfont = curfont->pfont;

    free_html_font (curfont->cfont);
    free (curfont);
    HTMLstate.fontstack = prevfont;
}

#line 406 "../../lib/common/htmlparse.y"
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union  {
  int    i;
  htmltxt_t*  txt;
  htmlcell_t*  cell;
  htmltbl_t*   tbl;
  htmlfont_t*  font;
  htmlimg_t*   img;
} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
#line 425 "y.tab.c"

/* compatibility with bison */
#ifdef YYPARSE_PARAM
/* compatibility with FreeBSD */
# ifdef YYPARSE_PARAM_TYPE
#  define YYPARSE_DECL() htmlparse(YYPARSE_PARAM_TYPE YYPARSE_PARAM)
# else
#  define YYPARSE_DECL() htmlparse(void *YYPARSE_PARAM)
# endif
#else
# define YYPARSE_DECL() htmlparse(void)
#endif

/* Parameters sent to lex. */
#ifdef YYLEX_PARAM
# define YYLEX_DECL() htmllex(void *YYLEX_PARAM)
# define YYLEX htmllex(YYLEX_PARAM)
#else
# define YYLEX_DECL() htmllex(void)
# define YYLEX htmllex()
#endif

/* Parameters sent to htmlerror. */
#ifndef YYERROR_DECL
#define YYERROR_DECL() htmlerror(const char *s)
#endif
#ifndef YYERROR_CALL
#define YYERROR_CALL(msg) htmlerror(msg)
#endif

extern int YYPARSE_DECL();

#define T_end_br 257
#define T_end_img 258
#define T_row 259
#define T_end_row 260
#define T_html 261
#define T_end_html 262
#define T_end_table 263
#define T_end_cell 264
#define T_end_font 265
#define T_string 266
#define T_error 267
#define T_n_italic 268
#define T_n_bold 269
#define T_n_underline 270
#define T_n_sup 271
#define T_n_sub 272
#define T_BR 273
#define T_br 274
#define T_IMG 275
#define T_img 276
#define T_table 277
#define T_cell 278
#define T_font 279
#define T_italic 280
#define T_bold 281
#define T_underline 282
#define T_sup 283
#define T_sub 284
#define YYERRCODE 256
static const short htmllhs[] = {                           -1,
    0,    0,    0,    1,    6,    6,    7,    7,    7,    7,
    7,    7,    7,    7,    9,   10,   11,   12,   15,   16,
   13,   14,   17,   18,   19,   20,    2,    2,    8,    8,
   23,    3,    4,    4,    4,    4,    4,   21,   21,   22,
   22,   26,   24,   25,   25,   28,   27,   29,   27,   30,
   27,   31,   27,    5,    5,
};
static const short htmllen[] = {                            2,
    3,    3,    1,    1,    2,    1,    1,    1,    3,    3,
    3,    3,    3,    3,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    2,    1,    1,    2,
    0,    6,    1,    3,    3,    3,    3,    1,    0,    1,
    2,    0,    4,    1,    2,    0,    4,    0,    4,    0,
    4,    0,    3,    2,    1,
};
static const short htmldefred[] = {                         0,
    3,    0,    0,   29,   28,    0,   15,   17,   19,   21,
   23,   25,    0,    8,   33,    0,    0,    6,    0,    0,
    0,    0,    0,    0,    0,    0,   27,    1,    2,    5,
    0,    0,    0,    0,    0,   30,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   31,   16,   34,    9,
   18,   35,   10,   22,   36,   11,   20,   37,   12,   24,
   13,   26,   14,    0,   42,    0,   40,    0,    0,   41,
    0,    0,   44,    0,   32,   55,    0,   48,   46,   50,
    0,   43,   45,   54,    0,    0,    0,   53,   49,   47,
   51,
};
static const short htmldgoto[] = {                          3,
   13,   14,   15,   16,   80,   17,   18,   31,   32,   49,
   33,   52,   34,   55,   35,   58,   24,   61,   25,   63,
   26,   66,   64,   67,   72,   68,   73,   86,   85,   87,
   81,
};
static const short htmlsindex[] = {                      -249,
    0,  -68,    0,    0,    0, -247,    0,    0,    0,    0,
    0,    0, -246,    0,    0, -245,  -68,    0, -258,  -68,
  -68,  -68,  -68,  -68,  -68, -264,    0,    0,    0,    0,
 -258,  -68,  -68,  -68,  -68,    0, -251, -218, -235, -156,
 -234, -137, -232, -118,  -99,  -80,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0, -214,    0, -248,    0, -210, -220,    0,
 -175, -254,    0, -258,    0,    0, -182,    0,    0,    0,
 -193,    0,    0,    0, -185, -184, -180,    0,    0,    0,
    0,
};
static const short htmlrindex[] = {                         0,
    0, -192,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0, -236,    0, -187, -192,
 -192, -192, -192,    0,    0,    0,    0,    0,    0,    0,
 -230,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0, -149,    0,
 -255,    0,    0, -130,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,
};
static const short htmlgindex[] = {                         0,
   17,    0,   37,   18,    0,  197,  -15,   -2,   -1,   64,
    1,   63,    2,   69,    3,   70,    0,    0,    0,    0,
   53,    0,    0,   65,    0,    0,   58,    0,    0,    0,
    0,
};
#define YYTABLESIZE 232
static const short htmltable[] = {                         19,
   20,   30,   21,   22,   23,   82,    1,   36,   52,   27,
   65,    2,   47,   48,   69,   28,   29,   19,   19,   19,
   19,   39,   30,   71,   30,    4,   30,    4,   30,   30,
   30,    7,   51,    7,    7,   54,   57,    7,    7,    7,
    7,    7,    7,    7,   65,    4,   48,    4,    7,    7,
    7,    7,    7,    7,    5,    6,   37,   39,   41,   43,
    7,    8,    9,   10,   11,   12,   74,   71,   19,   20,
   88,   21,   22,   23,    7,   84,    7,    7,   89,   90,
    7,    7,    7,   91,   39,    7,    7,   78,   79,   38,
    4,    7,    7,    7,    7,    7,    7,    5,    6,   76,
   77,   50,   53,    7,    8,    9,   10,   11,   12,    4,
   56,   51,   39,   59,   39,   39,    5,    6,   39,   39,
   39,   75,    7,    8,    9,   10,   11,   12,    4,   83,
   70,   38,   54,   38,   38,    5,    6,   38,   38,   38,
    0,    7,    8,    9,   10,   11,   12,    4,    0,    0,
   57,    0,    0,    0,    5,    6,    0,    0,    0,    0,
    7,    8,    9,   10,   11,   12,    4,    0,    0,    0,
    0,   60,    0,    5,    6,    0,    0,    0,    0,    7,
    8,    9,   10,   11,   12,    4,    0,    0,    0,    0,
    0,   62,    5,    6,    0,    0,    0,    4,    7,    8,
    9,   10,   11,   12,    5,    6,    0,    0,    0,    0,
    7,    8,    9,   10,   11,   12,   38,   40,   42,   44,
   45,   46,    0,    0,    0,    0,    0,    0,   38,   40,
   42,   44,
};
static const short htmlcheck[] = {                          2,
    2,   17,    2,    2,    2,  260,  256,  266,  264,  257,
  259,  261,  277,  265,  263,  262,  262,   20,   21,   22,
   23,  277,   38,  278,   40,  262,   42,  264,   44,   45,
   46,  262,  268,  264,  265,  270,  269,  268,  269,  270,
  271,  272,  273,  274,  259,  266,  265,  266,  279,  280,
  281,  282,  283,  284,  273,  274,   20,   21,   22,   23,
  279,  280,  281,  282,  283,  284,   69,  278,   71,   71,
  264,   71,   71,   71,  262,  258,  264,  265,  264,  264,
  268,  269,  270,  264,  277,  273,  274,   71,   71,  277,
  266,  279,  280,  281,  282,  283,  284,  273,  274,  275,
  276,   38,   40,  279,  280,  281,  282,  283,  284,  266,
   42,  268,  262,   44,  264,  265,  273,  274,  268,  269,
  270,   69,  279,  280,  281,  282,  283,  284,  266,   72,
   66,  262,  270,  264,  265,  273,  274,  268,  269,  270,
   -1,  279,  280,  281,  282,  283,  284,  266,   -1,   -1,
  269,   -1,   -1,   -1,  273,  274,   -1,   -1,   -1,   -1,
  279,  280,  281,  282,  283,  284,  266,   -1,   -1,   -1,
   -1,  271,   -1,  273,  274,   -1,   -1,   -1,   -1,  279,
  280,  281,  282,  283,  284,  266,   -1,   -1,   -1,   -1,
   -1,  272,  273,  274,   -1,   -1,   -1,  266,  279,  280,
  281,  282,  283,  284,  273,  274,   -1,   -1,   -1,   -1,
  279,  280,  281,  282,  283,  284,   20,   21,   22,   23,
   24,   25,   -1,   -1,   -1,   -1,   -1,   -1,   32,   33,
   34,   35,
};
#define YYFINAL 3
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 284
#define YYTRANSLATE(a) ((a) > YYMAXTOKEN ? (YYMAXTOKEN + 1) : (a))
#if YYDEBUG
static const char *htmlname[] = {

"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"T_end_br","T_end_img","T_row",
"T_end_row","T_html","T_end_html","T_end_table","T_end_cell","T_end_font",
"T_string","T_error","T_n_italic","T_n_bold","T_n_underline","T_n_sup",
"T_n_sub","T_BR","T_br","T_IMG","T_img","T_table","T_cell","T_font","T_italic",
"T_bold","T_underline","T_sup","T_sub","illegal-symbol",
};
static const char *htmlrule[] = {
"$accept : html",
"html : T_html fonttext T_end_html",
"html : T_html fonttable T_end_html",
"html : error",
"fonttext : text",
"text : text textitem",
"text : textitem",
"textitem : string",
"textitem : br",
"textitem : font text n_font",
"textitem : italic text n_italic",
"textitem : underline text n_underline",
"textitem : bold text n_bold",
"textitem : sup text n_sup",
"textitem : sub text n_sub",
"font : T_font",
"n_font : T_end_font",
"italic : T_italic",
"n_italic : T_n_italic",
"bold : T_bold",
"n_bold : T_n_bold",
"underline : T_underline",
"n_underline : T_n_underline",
"sup : T_sup",
"n_sup : T_n_sup",
"sub : T_sub",
"n_sub : T_n_sub",
"br : T_br T_end_br",
"br : T_BR",
"string : T_string",
"string : string T_string",
"$$1 :",
"table : opt_space T_table $$1 rows T_end_table opt_space",
"fonttable : table",
"fonttable : font table n_font",
"fonttable : italic table n_italic",
"fonttable : underline table n_underline",
"fonttable : bold table n_bold",
"opt_space : string",
"opt_space :",
"rows : row",
"rows : rows row",
"$$2 :",
"row : T_row $$2 cells T_end_row",
"cells : cell",
"cells : cells cell",
"$$3 :",
"cell : T_cell fonttable $$3 T_end_cell",
"$$4 :",
"cell : T_cell fonttext $$4 T_end_cell",
"$$5 :",
"cell : T_cell image $$5 T_end_cell",
"$$6 :",
"cell : T_cell $$6 T_end_cell",
"image : T_img T_end_img",
"image : T_IMG",

};
#endif

int      htmldebug;
int      htmlnerrs;

int      htmlerrflag;
int      htmlchar;
YYSTYPE  htmlval;
YYSTYPE  htmllval;

/* define the initial stack-sizes */
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH  YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 10000
#define YYMAXDEPTH  10000
#endif
#endif

#define YYINITSTACKSIZE 200

typedef struct {
    unsigned stacksize;
    short    *s_base;
    short    *s_mark;
    short    *s_last;
    YYSTYPE  *l_base;
    YYSTYPE  *l_mark;
} YYSTACKDATA;
/* variables for the parser stack */
static YYSTACKDATA htmlstack;
#line 553 "../../lib/common/htmlparse.y"

/* parseHTML:
 * Return parsed label or NULL if failure.
 * Set warn to 0 on success; 1 for warning message; 2 if no expat.
 */
htmllabel_t*
parseHTML (char* txt, int* warn, int charset)
{
  unsigned char buf[SMALLBUF];
  agxbuf        str;
  htmllabel_t*  l;
  sfont_t       dfltf;

  dfltf.cfont = NULL;
  dfltf.pfont = NULL;
  HTMLstate.fontstack = &dfltf;
  HTMLstate.tblstack = 0;
  HTMLstate.lbl = 0;
  HTMLstate.fitemList = dtopen(&fstrDisc, Dtqueue);
  HTMLstate.fparaList = dtopen(&fparaDisc, Dtqueue);

  agxbinit (&str, SMALLBUF, buf);
  HTMLstate.str = &str;
  
  if (initHTMLlexer (txt, &str, charset)) {/* failed: no libexpat - give up */
    *warn = 2;
    l = NULL;
  }
  else {
    htmlparse();
    *warn = clearHTMLlexer ();
    l = HTMLstate.lbl;
  }

  dtclose (HTMLstate.fitemList);
  dtclose (HTMLstate.fparaList);
  
  HTMLstate.fitemList = NULL;
  HTMLstate.fparaList = NULL;
  HTMLstate.fontstack = NULL;
  
  agxbfree (&str);

  return l;
}

#line 765 "y.tab.c"

#if YYDEBUG
#include <stdio.h>		/* needed for printf */
#endif

#include <stdlib.h>	/* needed for malloc, etc */
#include <string.h>	/* needed for memset */

/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int htmlgrowstack(YYSTACKDATA *data)
{
    int i;
    unsigned newsize;
    short *newss;
    YYSTYPE *newvs;

    if ((newsize = data->stacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return -1;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;

    i = (int) (data->s_mark - data->s_base);
    newss = (short *)realloc(data->s_base, newsize * sizeof(*newss));
    if (newss == 0)
        return -1;

    data->s_base = newss;
    data->s_mark = newss + i;

    newvs = (YYSTYPE *)realloc(data->l_base, newsize * sizeof(*newvs));
    if (newvs == 0)
        return -1;

    data->l_base = newvs;
    data->l_mark = newvs + i;

    data->stacksize = newsize;
    data->s_last = data->s_base + newsize - 1;
    return 0;
}

#if YYPURE || defined(YY_NO_LEAKS)
static void htmlfreestack(YYSTACKDATA *data)
{
    free(data->s_base);
    free(data->l_base);
    memset(data, 0, sizeof(*data));
}
#else
#define htmlfreestack(data) /* nothing */
#endif

#define YYABORT  goto htmlabort
#define YYREJECT goto htmlabort
#define YYACCEPT goto htmlaccept
#define YYERROR  goto htmlerrlab

int
YYPARSE_DECL()
{
    int htmlm, htmln, htmlstate;
#if YYDEBUG
    const char *htmls;

    if ((htmls = getenv("YYDEBUG")) != 0)
    {
        htmln = *htmls;
        if (htmln >= '0' && htmln <= '9')
            htmldebug = htmln - '0';
    }
#endif

    htmlnerrs = 0;
    htmlerrflag = 0;
    htmlchar = YYEMPTY;
    htmlstate = 0;

#if YYPURE
    memset(&htmlstack, 0, sizeof(htmlstack));
#endif

    if (htmlstack.s_base == NULL && htmlgrowstack(&htmlstack)) goto htmloverflow;
    htmlstack.s_mark = htmlstack.s_base;
    htmlstack.l_mark = htmlstack.l_base;
    htmlstate = 0;
    *htmlstack.s_mark = 0;

htmlloop:
    if ((htmln = htmldefred[htmlstate]) != 0) goto htmlreduce;
    if (htmlchar < 0)
    {
        if ((htmlchar = YYLEX) < 0) htmlchar = 0;
#if YYDEBUG
        if (htmldebug)
        {
            htmls = htmlname[YYTRANSLATE(htmlchar)];
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, htmlstate, htmlchar, htmls);
        }
#endif
    }
    if ((htmln = htmlsindex[htmlstate]) && (htmln += htmlchar) >= 0 &&
            htmln <= YYTABLESIZE && htmlcheck[htmln] == htmlchar)
    {
#if YYDEBUG
        if (htmldebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, htmlstate, htmltable[htmln]);
#endif
        if (htmlstack.s_mark >= htmlstack.s_last && htmlgrowstack(&htmlstack))
        {
            goto htmloverflow;
        }
        htmlstate = htmltable[htmln];
        *++htmlstack.s_mark = htmltable[htmln];
        *++htmlstack.l_mark = htmllval;
        htmlchar = YYEMPTY;
        if (htmlerrflag > 0)  --htmlerrflag;
        goto htmlloop;
    }
    if ((htmln = htmlrindex[htmlstate]) && (htmln += htmlchar) >= 0 &&
            htmln <= YYTABLESIZE && htmlcheck[htmln] == htmlchar)
    {
        htmln = htmltable[htmln];
        goto htmlreduce;
    }
    if (htmlerrflag) goto htmlinrecovery;

    htmlerror("syntax error");

    goto htmlerrlab;

htmlerrlab:
    ++htmlnerrs;

htmlinrecovery:
    if (htmlerrflag < 3)
    {
        htmlerrflag = 3;
        for (;;)
        {
            if ((htmln = htmlsindex[*htmlstack.s_mark]) && (htmln += YYERRCODE) >= 0 &&
                    htmln <= YYTABLESIZE && htmlcheck[htmln] == YYERRCODE)
            {
#if YYDEBUG
                if (htmldebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *htmlstack.s_mark, htmltable[htmln]);
#endif
                if (htmlstack.s_mark >= htmlstack.s_last && htmlgrowstack(&htmlstack))
                {
                    goto htmloverflow;
                }
                htmlstate = htmltable[htmln];
                *++htmlstack.s_mark = htmltable[htmln];
                *++htmlstack.l_mark = htmllval;
                goto htmlloop;
            }
            else
            {
#if YYDEBUG
                if (htmldebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *htmlstack.s_mark);
#endif
                if (htmlstack.s_mark <= htmlstack.s_base) goto htmlabort;
                --htmlstack.s_mark;
                --htmlstack.l_mark;
            }
        }
    }
    else
    {
        if (htmlchar == 0) goto htmlabort;
#if YYDEBUG
        if (htmldebug)
        {
            htmls = htmlname[YYTRANSLATE(htmlchar)];
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, htmlstate, htmlchar, htmls);
        }
#endif
        htmlchar = YYEMPTY;
        goto htmlloop;
    }

htmlreduce:
#if YYDEBUG
    if (htmldebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, htmlstate, htmln, htmlrule[htmln]);
#endif
    htmlm = htmllen[htmln];
    if (htmlm)
        htmlval = htmlstack.l_mark[1-htmlm];
    else
        memset(&htmlval, 0, sizeof htmlval);
    switch (htmln)
    {
case 1:
#line 433 "../../lib/common/htmlparse.y"
	{ HTMLstate.lbl = mkLabel(htmlstack.l_mark[-1].txt,HTML_TEXT); }
break;
case 2:
#line 434 "../../lib/common/htmlparse.y"
	{ HTMLstate.lbl = mkLabel(htmlstack.l_mark[-1].tbl,HTML_TBL); }
break;
case 3:
#line 435 "../../lib/common/htmlparse.y"
	{ cleanup(); YYABORT; }
break;
case 4:
#line 438 "../../lib/common/htmlparse.y"
	{ htmlval.txt = mkText(); }
break;
case 7:
#line 445 "../../lib/common/htmlparse.y"
	{ appendFItemList(HTMLstate.str);}
break;
case 8:
#line 446 "../../lib/common/htmlparse.y"
	{appendFLineList(htmlstack.l_mark[0].i);}
break;
case 15:
#line 455 "../../lib/common/htmlparse.y"
	{ pushFont (htmlstack.l_mark[0].font); }
break;
case 16:
#line 458 "../../lib/common/htmlparse.y"
	{ popFont (); }
break;
case 17:
#line 461 "../../lib/common/htmlparse.y"
	{pushFont(htmlstack.l_mark[0].font);}
break;
case 18:
#line 464 "../../lib/common/htmlparse.y"
	{popFont();}
break;
case 19:
#line 467 "../../lib/common/htmlparse.y"
	{pushFont(htmlstack.l_mark[0].font);}
break;
case 20:
#line 470 "../../lib/common/htmlparse.y"
	{popFont();}
break;
case 21:
#line 473 "../../lib/common/htmlparse.y"
	{pushFont(htmlstack.l_mark[0].font);}
break;
case 22:
#line 476 "../../lib/common/htmlparse.y"
	{popFont();}
break;
case 23:
#line 479 "../../lib/common/htmlparse.y"
	{pushFont(htmlstack.l_mark[0].font);}
break;
case 24:
#line 482 "../../lib/common/htmlparse.y"
	{popFont();}
break;
case 25:
#line 485 "../../lib/common/htmlparse.y"
	{pushFont(htmlstack.l_mark[0].font);}
break;
case 26:
#line 488 "../../lib/common/htmlparse.y"
	{popFont();}
break;
case 27:
#line 491 "../../lib/common/htmlparse.y"
	{ htmlval.i = htmlstack.l_mark[-1].i; }
break;
case 28:
#line 492 "../../lib/common/htmlparse.y"
	{ htmlval.i = htmlstack.l_mark[0].i; }
break;
case 31:
#line 499 "../../lib/common/htmlparse.y"
	{ 
          if (nonSpace(agxbuse(HTMLstate.str))) {
            htmlerror ("Syntax error: non-space string used before <TABLE>");
            cleanup(); YYABORT;
          }
          htmlstack.l_mark[0].tbl->u.p.prev = HTMLstate.tblstack;
          htmlstack.l_mark[0].tbl->u.p.rows = dtopen(&rowDisc, Dtqueue);
          HTMLstate.tblstack = htmlstack.l_mark[0].tbl;
          htmlstack.l_mark[0].tbl->font = dupFont (HTMLstate.fontstack->cfont);
          htmlval.tbl = htmlstack.l_mark[0].tbl;
        }
break;
case 32:
#line 510 "../../lib/common/htmlparse.y"
	{
          if (nonSpace(agxbuse(HTMLstate.str))) {
            htmlerror ("Syntax error: non-space string used after </TABLE>");
            cleanup(); YYABORT;
          }
          htmlval.tbl = HTMLstate.tblstack;
          HTMLstate.tblstack = HTMLstate.tblstack->u.p.prev;
        }
break;
case 33:
#line 520 "../../lib/common/htmlparse.y"
	{ htmlval.tbl = htmlstack.l_mark[0].tbl; }
break;
case 34:
#line 521 "../../lib/common/htmlparse.y"
	{ htmlval.tbl=htmlstack.l_mark[-1].tbl; }
break;
case 35:
#line 522 "../../lib/common/htmlparse.y"
	{ htmlval.tbl=htmlstack.l_mark[-1].tbl; }
break;
case 36:
#line 523 "../../lib/common/htmlparse.y"
	{ htmlval.tbl=htmlstack.l_mark[-1].tbl; }
break;
case 37:
#line 524 "../../lib/common/htmlparse.y"
	{ htmlval.tbl=htmlstack.l_mark[-1].tbl; }
break;
case 42:
#line 535 "../../lib/common/htmlparse.y"
	{ addRow (); }
break;
case 46:
#line 542 "../../lib/common/htmlparse.y"
	{ setCell(htmlstack.l_mark[-1].cell,htmlstack.l_mark[0].tbl,HTML_TBL); }
break;
case 48:
#line 543 "../../lib/common/htmlparse.y"
	{ setCell(htmlstack.l_mark[-1].cell,htmlstack.l_mark[0].txt,HTML_TEXT); }
break;
case 50:
#line 544 "../../lib/common/htmlparse.y"
	{ setCell(htmlstack.l_mark[-1].cell,htmlstack.l_mark[0].img,HTML_IMAGE); }
break;
case 52:
#line 545 "../../lib/common/htmlparse.y"
	{ setCell(htmlstack.l_mark[0].cell,mkText(),HTML_TEXT); }
break;
case 54:
#line 548 "../../lib/common/htmlparse.y"
	{ htmlval.img = htmlstack.l_mark[-1].img; }
break;
case 55:
#line 549 "../../lib/common/htmlparse.y"
	{ htmlval.img = htmlstack.l_mark[0].img; }
break;
#line 1120 "y.tab.c"
    }
    htmlstack.s_mark -= htmlm;
    htmlstate = *htmlstack.s_mark;
    htmlstack.l_mark -= htmlm;
    htmlm = htmllhs[htmln];
    if (htmlstate == 0 && htmlm == 0)
    {
#if YYDEBUG
        if (htmldebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        htmlstate = YYFINAL;
        *++htmlstack.s_mark = YYFINAL;
        *++htmlstack.l_mark = htmlval;
        if (htmlchar < 0)
        {
            if ((htmlchar = YYLEX) < 0) htmlchar = 0;
#if YYDEBUG
            if (htmldebug)
            {
                htmls = htmlname[YYTRANSLATE(htmlchar)];
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, htmlchar, htmls);
            }
#endif
        }
        if (htmlchar == 0) goto htmlaccept;
        goto htmlloop;
    }
    if ((htmln = htmlgindex[htmlm]) && (htmln += htmlstate) >= 0 &&
            htmln <= YYTABLESIZE && htmlcheck[htmln] == htmlstate)
        htmlstate = htmltable[htmln];
    else
        htmlstate = htmldgoto[htmlm];
#if YYDEBUG
    if (htmldebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *htmlstack.s_mark, htmlstate);
#endif
    if (htmlstack.s_mark >= htmlstack.s_last && htmlgrowstack(&htmlstack))
    {
        goto htmloverflow;
    }
    *++htmlstack.s_mark = (short) htmlstate;
    *++htmlstack.l_mark = htmlval;
    goto htmlloop;

htmloverflow:
    htmlerror("yacc stack overflow");

htmlabort:
    htmlfreestack(&htmlstack);
    return (1);

htmlaccept:
    htmlfreestack(&htmlstack);
    return (0);
}
