#ifndef lint
static const char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif

#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYPATCH 20140101

#define YYEMPTY        (-1)
#define yyclearin      (yychar = YYEMPTY)
#define yyerrok        (yyerrflag = 0)
#define YYRECOVERING() (yyerrflag != 0)

#define YYPREFIX "yy"

#define YYPURE 0

#line 15 "../../lib/graph/parser.y"

#include	"libgraph.h"

#ifdef DMALLOC
#include "dmalloc.h"
#endif

static char		*Port;
static char		In_decl,In_edge_stmt;
static int		Current_class,Agraph_type;
static Agsym_t		*headsubsym;
static Agsym_t		*tailsubsym;
static Agraph_t		*G;
static Agnode_t		*N;
static Agedge_t		*E;
static objstack_t	*SP;
#define GSTACK_SIZE 64
static Agraph_t         *Gstack[GSTACK_SIZE];
static int			GSP;

static void subgraph_warn (void)
{
    agerr (AGWARN, "The use of \"subgraph %s\", line %d, without a body is deprecated.\n",
	G->name, aglinenumber());
    agerr (AGPREV, "This may cause unexpected behavior or crash the program.\n");
    agerr (AGPREV, "Please use a single definition of the subgraph within the context of its parent graph \"%s\"\n", Gstack[GSP-2]->name);
}

static void push_subg(Agraph_t *g)
{
	if (GSP >= GSTACK_SIZE) {
		agerr (AGERR, "Gstack overflow in graph parser\n"); exit(1);
	}
	G = Gstack[GSP++] = g;
}

static Agraph_t *pop_subg(void)
{
	Agraph_t		*g;
	if (GSP == 0) {
		agerr (AGERR, "Gstack underflow in graph parser\n"); exit(1);
	}
	g = Gstack[--GSP];					/* graph being popped off */
	if (GSP > 0) G = Gstack[GSP - 1];	/* current graph */
	else G = 0;
	return g;
}

static objport_t pop_gobj(void)
{
	objport_t	rv;
	rv.obj = pop_subg();
	rv.port = NULL;
	return rv;
}

static void anonname(char* buf)
{
	static int		anon_id = 0;

	sprintf(buf,"_anonymous_%d",anon_id++);
}

static void begin_graph(char *name)
{
	Agraph_t		*g;
	char			buf[SMALLBUF];

	if (!name) {
		anonname(buf);
		name = buf;
    }
	g = AG.parsed_g = agopen(name,Agraph_type);
	Current_class = TAG_GRAPH;
	headsubsym = tailsubsym = NULL;
	push_subg(g);
	In_decl = TRUE;
}

static void end_graph(void)
{
	pop_subg();
}

static Agnode_t *bind_node(char *name)
{
	Agnode_t	*n = agnode(G,name);
	In_decl = FALSE;
	return n;
}

static void anonsubg(void)
{
	char			buf[SMALLBUF];
	Agraph_t			*subg;

	In_decl = FALSE;
	anonname(buf);
	subg = agsubg(G,buf);
	push_subg(subg);
}

#if 0 /* NOT USED */
static int isanonsubg(Agraph_t *g)
{
	return (strncmp("_anonymous_",g->name,11) == 0);
}
#endif

static void begin_edgestmt(objport_t objp)
{
	struct objstack_t	*new_sp;

	new_sp = NEW(objstack_t);
	new_sp->link = SP;
	SP = new_sp;
	SP->list = SP->last = NEW(objlist_t);
	SP->list->data  = objp;
	SP->list->link = NULL;
	SP->in_edge_stmt = In_edge_stmt;
	SP->subg = G;
	agpushproto(G);
	In_edge_stmt = TRUE;
}

static void mid_edgestmt(objport_t objp)
{
	SP->last->link = NEW(objlist_t);
	SP->last = SP->last->link;
	SP->last->data = objp;
	SP->last->link = NULL;
}

static void end_edgestmt(void)
{
	objstack_t	*old_SP;
	objlist_t	*tailptr,*headptr,*freeptr;
	Agraph_t		*t_graph,*h_graph;
	Agnode_t	*t_node,*h_node,*t_first,*h_first;
	Agedge_t	*e;
	char		*tport,*hport;

	for (tailptr = SP->list; tailptr->link; tailptr = tailptr->link) {
		headptr = tailptr->link;
		tport = tailptr->data.port;
		hport = headptr->data.port;
		if (TAG_OF(tailptr->data.obj) == TAG_NODE) {
			t_graph = NULL;
			t_first = (Agnode_t*)(tailptr->data.obj);
		}
		else {
			t_graph = (Agraph_t*)(tailptr->data.obj);
			t_first = agfstnode(t_graph);
		}
		if (TAG_OF(headptr->data.obj) == TAG_NODE) {
			h_graph = NULL;
			h_first = (Agnode_t*)(headptr->data.obj);
		}
		else {
			h_graph = (Agraph_t*)(headptr->data.obj);
			h_first = agfstnode(h_graph);
		}

		for (t_node = t_first; t_node; t_node = t_graph ?
		  agnxtnode(t_graph,t_node) : NULL) {
			for (h_node = h_first; h_node; h_node = h_graph ?
			  agnxtnode(h_graph,h_node) : NULL ) {
				e = agedge(G,t_node,h_node);
				if (e) {
					char	*tp = tport;
					char 	*hp = hport;
					if ((e->tail != e->head) && (e->head == t_node)) {
						/* could happen with an undirected edge */
						char 	*temp;
						temp = tp; tp = hp; hp = temp;
					}
					if (tp && tp[0]) {
						agxset(e,TAILX,tp);
						agstrfree(tp); 
					}
					if (hp && hp[0]) {
						agxset(e,HEADX,hp);
						agstrfree(hp); 
					}
				}
			}
		}
	}
	tailptr = SP->list; 
	while (tailptr) {
		freeptr = tailptr;
		tailptr = tailptr->link;
		if (TAG_OF(freeptr->data.obj) == TAG_NODE)
		free(freeptr);
	}
	if (G != SP->subg) abort();
	agpopproto(G);
	In_edge_stmt = SP->in_edge_stmt;
	old_SP = SP;
	SP = SP->link;
	In_decl = FALSE;
	free(old_SP);
	Current_class = TAG_GRAPH;
}

#if 0 /* NOT USED */
static Agraph_t *parent_of(Agraph_t *g)
{
	Agraph_t		*rv;
	rv = agusergraph(agfstin(g->meta_node->graph,g->meta_node)->tail);
	return rv;
}
#endif

static void attr_set(char *name, char *value)
{
	Agsym_t		*ap = NULL;
	char		*defval = "";

	if (In_decl && (G->root == G)) defval = value;
	switch (Current_class) {
		case TAG_NODE:
			ap = agfindattr(G->proto->n,name);
			if (ap == NULL)
				ap = agnodeattr(AG.parsed_g,name,defval);
            else if (ap->fixed && In_decl)
              return;
			agxset(N,ap->index,value);
			break;
		case TAG_EDGE:
			ap = agfindattr(G->proto->e,name);
			if (ap == NULL)
				ap = agedgeattr(AG.parsed_g,name,defval);
            else if (ap->fixed && In_decl && (G->root == G))
              return;
			agxset(E,ap->index,value);
			break;
		case 0:		/* default */
		case TAG_GRAPH:
			ap = agfindattr(G,name);
			if (ap == NULL) 
				ap = agraphattr(AG.parsed_g,name,defval);
            else if (ap->fixed && In_decl)
              return;
			agxset(G,ap->index,value);
			break;
	}
}

/* concat:
 */
static char*
concat (char* s1, char* s2)
{
  char*  s;
  char   buf[BUFSIZ];
  char*  sym;
  int    len = strlen(s1) + strlen(s2) + 1;

  if (len <= BUFSIZ) sym = buf;
  else sym = (char*)malloc(len);
  strcpy(sym,s1);
  strcat(sym,s2);
  s = agstrdup (sym);
  if (sym != buf) free (sym);
  return s;
}

/* concat3:
 */
static char*
concat3 (char* s1, char* s2, char*s3)
{
  char*  s;
  char   buf[BUFSIZ];
  char*  sym;
  int    len = strlen(s1) + strlen(s2) + strlen(s3) + 1;

  if (len <= BUFSIZ) sym = buf;
  else sym = (char*)malloc(len);
  strcpy(sym,s1);
  strcat(sym,s2);
  strcat(sym,s3);
  s = agstrdup (sym);
  if (sym != buf) free (sym);
  return s;
}

#line 305 "../../lib/graph/parser.y"
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union	{
			int					i;
			char				*str;
			struct objport_t	obj;
			struct Agnode_t		*n;
} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
#line 322 "y.tab.c"

/* compatibility with bison */
#ifdef YYPARSE_PARAM
/* compatibility with FreeBSD */
# ifdef YYPARSE_PARAM_TYPE
#  define YYPARSE_DECL() yyparse(YYPARSE_PARAM_TYPE YYPARSE_PARAM)
# else
#  define YYPARSE_DECL() yyparse(void *YYPARSE_PARAM)
# endif
#else
# define YYPARSE_DECL() yyparse(void)
#endif

/* Parameters sent to lex. */
#ifdef YYLEX_PARAM
# define YYLEX_DECL() yylex(void *YYLEX_PARAM)
# define YYLEX yylex(YYLEX_PARAM)
#else
# define YYLEX_DECL() yylex(void)
# define YYLEX yylex()
#endif

/* Parameters sent to yyerror. */
#ifndef YYERROR_DECL
#define YYERROR_DECL() yyerror(const char *s)
#endif
#ifndef YYERROR_CALL
#define YYERROR_CALL(msg) yyerror(msg)
#endif

extern int YYPARSE_DECL();

#define T_graph 257
#define T_digraph 258
#define T_strict 259
#define T_node 260
#define T_edge 261
#define T_edgeop 262
#define T_symbol 263
#define T_qsymbol 264
#define T_subgraph 265
#define YYERRCODE 256
static const short yylhs[] = {                           -1,
    8,    0,    0,    0,    3,    3,    7,    7,    7,    7,
   10,   10,   10,   11,   11,   13,   13,   14,   15,   15,
   16,   17,   12,   12,    9,    9,   18,   18,   19,   19,
   19,   20,   20,   20,   20,   23,   23,    5,    4,   24,
   24,   24,   25,   21,   27,   28,   22,   29,   30,   22,
   26,   31,   26,   26,   32,   26,    6,   34,    6,   35,
    6,    6,   33,    1,    1,    2,    2,
};
static const short yylen[] = {                            2,
    0,    6,    1,    0,    1,    0,    1,    2,    1,    2,
    1,    1,    1,    3,    0,    0,    1,    3,    2,    0,
    1,    3,    1,    1,    1,    0,    1,    2,    1,    2,
    1,    1,    1,    1,    1,    2,    1,    2,    1,    0,
    2,    4,    0,    3,    0,    0,    5,    0,    0,    5,
    2,    0,    4,    2,    0,    4,    4,    0,    5,    0,
    4,    1,    2,    1,    1,    1,    3,
};
static const short yydefred[] = {                         0,
    3,    7,    9,    0,    0,    0,    8,   10,   64,   66,
    5,    0,    1,    0,    0,   67,    0,   31,   11,   12,
   13,    0,   60,    0,    0,    0,    0,    0,    0,   37,
    0,   27,    0,   32,   33,   34,    0,   58,   63,    0,
    0,    0,   38,   20,    0,    0,    2,    0,   36,   28,
   30,    0,    0,    0,   22,    0,    0,   44,    0,   46,
   49,    0,    0,    0,   23,    0,    0,   61,    0,   19,
   39,    0,    0,   20,   20,   18,   17,    0,   57,   59,
   42,    0,    0,   47,   50,   14,   53,   56,
};
static const short yydgoto[] = {                          5,
   24,   12,   13,   25,   26,   27,    6,   15,   28,   29,
   63,   64,   78,   49,   57,   58,   30,   31,   32,   33,
   34,   35,   36,   43,   44,   60,   45,   74,   46,   75,
   82,   83,   37,   53,   40,
};
static const short yysindex[] = {                      -228,
    0,    0,    0, -250,    0, -251,    0,    0,    0,    0,
    0,  -34,    0, -245,  -97,    0,  -84,    0,    0,    0,
    0, -112,    0,  -29,  -25,    0,    0,  -87,  -51,    0,
  -84,    0,  -18,    0,    0,    0,  -79,    0,    0,  -84,
 -251, -251,    0,    0, -217, -217,    0, -251,    0,    0,
    0,  -84,  -84,  -75,    0,  -12,  -51,    0, -102,    0,
    0,  -29,  -42,    9,    0,  -71,  -68,    0, -251,    0,
    0,    0,    0,    0,    0,    0,    0, -251,    0,    0,
    0, -217, -217,    0,    0,    0,    0,    0,
};
static const short yyrindex[] = {                        60,
    0,    0,    0,    0,    0,  -62,    0,    0,    0,    0,
    0,  -44,    0,    0,    0,    0,  -61,    0,    0,    0,
    0,    0,    0,  -57,  -32,  -22,   23,    0,    0,    0,
  -60,    0, -107,    0,    0,    0,   35,    0,    0,  -61,
    0,    0,    0,    0,    0,    0,    0,  -26,    0,    0,
    0,  -61,  -61,    0,    0,  -11,   45,    0,    0,    0,
    0,  -41,    0,  -89,    0,    0,    0,    0,    0,    0,
    0,   -1,   11,    0,    0,    0,    0,  -26,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,
};
static const short yygindex[] = {                         0,
   14,    0,    0,    0,    4,   12,    0,    0,  -30,    0,
   -6,    0,    0,   17,    0,  -50,  -43,    0,   44,    0,
    0,    0,    0,    0,    0,  -40,    0,    0,    0,    0,
    0,    0,    0,    0,    0,
};
#define YYTABLESIZE 310
static const short yytable[] = {                         65,
   39,   39,   24,   16,   65,   61,    7,    8,   14,   54,
   38,    9,   10,   65,   65,   29,   65,   29,   16,   11,
   23,   66,   67,   84,   85,   17,   40,    1,    2,    3,
    4,   41,   42,   39,   65,   39,   43,   47,   23,   48,
   51,   87,   88,   52,   59,   69,   65,   41,   65,   68,
   76,   24,   77,   79,   55,   56,   80,   51,   40,    4,
    6,   62,   72,   26,   25,   39,   15,   39,   43,   54,
   73,   86,   71,   70,   50,    0,    0,    0,   65,   41,
   65,   35,   81,    0,    0,    0,    0,    0,    0,   51,
   40,   62,   40,   62,    0,    0,    0,    0,    0,    0,
   43,   54,   43,   21,    0,    0,    0,    0,    0,    0,
    0,   41,    0,   41,    0,    0,    0,    0,    0,    0,
    0,   51,    0,   51,    0,   62,    0,    0,    0,    0,
    0,    0,    0,   54,    0,   54,    0,    0,    0,    0,
    0,    0,    0,    0,    0,   35,    0,   35,   29,   29,
    9,   10,   29,   29,    0,   29,   29,   29,    0,   62,
    9,   10,   22,    0,    0,    0,    0,   21,    0,   21,
    0,   18,   19,   16,   16,   20,   21,    0,    9,   10,
   22,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,   39,   39,
    0,    0,   39,   39,   39,   39,   39,   39,    0,    0,
    0,   65,   65,    0,    0,   65,   65,   65,   65,   65,
   65,   24,   24,   40,   40,    0,    0,   40,   40,   40,
   40,   40,   40,   43,   43,    0,    0,   43,   43,   45,
   43,   43,   43,    0,   41,   41,    0,    0,   41,   41,
   41,   41,   41,   41,   51,   51,    0,    0,   51,   51,
   52,   51,   51,   51,    0,    0,   54,   54,    0,    0,
   54,   54,   55,   54,   54,   54,    0,    0,   35,   35,
    0,    0,   35,   35,   48,   35,   35,   35,    0,    0,
   62,   62,    0,    0,   62,   62,   62,   62,   62,   62,
   21,   21,    0,    0,   21,   21,    0,   21,   21,   21,
};
static const short yycheck[] = {                         44,
   58,   59,   44,   93,   48,   46,  257,  258,   43,   40,
  123,  263,  264,   58,   59,  123,   61,  125,  264,    6,
  123,   52,   53,   74,   75,  123,   59,  256,  257,  258,
  259,   61,   58,   91,   78,   22,   59,  125,  123,   91,
   59,   82,   83,  123,  262,   58,   91,   59,   93,  125,
   93,   93,   44,  125,   41,   42,  125,   59,   91,    0,
  123,   48,   59,  125,  125,  123,   93,  125,   91,   59,
   59,   78,   59,   57,   31,   -1,   -1,   -1,  123,   91,
  125,   59,   69,   -1,   -1,   -1,   -1,   -1,   -1,   91,
  123,   78,  125,   59,   -1,   -1,   -1,   -1,   -1,   -1,
  123,   91,  125,   59,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,  123,   -1,  125,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,  123,   -1,  125,   -1,   91,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,  123,   -1,  125,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,  123,   -1,  125,  256,  257,
  263,  264,  260,  261,   -1,  263,  264,  265,   -1,  125,
  263,  264,  265,   -1,   -1,   -1,   -1,  123,   -1,  125,
   -1,  256,  257,  263,  264,  260,  261,   -1,  263,  264,
  265,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  256,  257,
   -1,   -1,  260,  261,  262,  263,  264,  265,   -1,   -1,
   -1,  256,  257,   -1,   -1,  260,  261,  262,  263,  264,
  265,  263,  264,  256,  257,   -1,   -1,  260,  261,  262,
  263,  264,  265,  256,  257,   -1,   -1,  260,  261,  262,
  263,  264,  265,   -1,  256,  257,   -1,   -1,  260,  261,
  262,  263,  264,  265,  256,  257,   -1,   -1,  260,  261,
  262,  263,  264,  265,   -1,   -1,  256,  257,   -1,   -1,
  260,  261,  262,  263,  264,  265,   -1,   -1,  256,  257,
   -1,   -1,  260,  261,  262,  263,  264,  265,   -1,   -1,
  256,  257,   -1,   -1,  260,  261,  262,  263,  264,  265,
  256,  257,   -1,   -1,  260,  261,   -1,  263,  264,  265,
};
#define YYFINAL 5
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 265
#define YYTRANSLATE(a) ((a) > YYMAXTOKEN ? (YYMAXTOKEN + 1) : (a))
#if YYDEBUG
static const char *yyname[] = {

"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,"'+'","','",0,0,0,0,0,0,0,0,0,0,0,0,0,"':'","';'",0,"'='",0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'['",0,"']'",0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'{'",0,"'}'",0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,"T_graph","T_digraph","T_strict","T_node","T_edge","T_edgeop","T_symbol",
"T_qsymbol","T_subgraph","illegal-symbol",
};
static const char *yyrule[] = {
"$accept : file",
"$$1 :",
"file : graph_type optgraphname $$1 '{' stmt_list '}'",
"file : error",
"file :",
"optgraphname : symbol",
"optgraphname :",
"graph_type : T_graph",
"graph_type : T_strict T_graph",
"graph_type : T_digraph",
"graph_type : T_strict T_digraph",
"attr_class : T_graph",
"attr_class : T_node",
"attr_class : T_edge",
"inside_attr_list : iattr_set optcomma inside_attr_list",
"inside_attr_list :",
"optcomma :",
"optcomma : ','",
"attr_list : '[' inside_attr_list ']'",
"rec_attr_list : rec_attr_list attr_list",
"rec_attr_list :",
"opt_attr_list : rec_attr_list",
"attr_set : symbol '=' symbol",
"iattr_set : attr_set",
"iattr_set : symbol",
"stmt_list : stmt_list1",
"stmt_list :",
"stmt_list1 : stmt",
"stmt_list1 : stmt_list1 stmt",
"stmt : stmt1",
"stmt : stmt1 ';'",
"stmt : error",
"stmt1 : node_stmt",
"stmt1 : edge_stmt",
"stmt1 : attr_stmt",
"stmt1 : subg_stmt",
"attr_stmt : attr_class attr_list",
"attr_stmt : attr_set",
"node_id : node_name node_port",
"node_name : symbol",
"node_port :",
"node_port : ':' symbol",
"node_port : ':' symbol ':' symbol",
"$$2 :",
"node_stmt : node_id $$2 opt_attr_list",
"$$3 :",
"$$4 :",
"edge_stmt : node_id $$3 edgeRHS $$4 opt_attr_list",
"$$5 :",
"$$6 :",
"edge_stmt : subg_stmt $$5 edgeRHS $$6 opt_attr_list",
"edgeRHS : T_edgeop node_id",
"$$7 :",
"edgeRHS : T_edgeop node_id $$7 edgeRHS",
"edgeRHS : T_edgeop subg_stmt",
"$$8 :",
"edgeRHS : T_edgeop subg_stmt $$8 edgeRHS",
"subg_stmt : subg_hdr '{' stmt_list '}'",
"$$9 :",
"subg_stmt : T_subgraph '{' $$9 stmt_list '}'",
"$$10 :",
"subg_stmt : '{' $$10 stmt_list '}'",
"subg_stmt : subg_hdr",
"subg_hdr : T_subgraph symbol",
"symbol : T_symbol",
"symbol : qsymbol",
"qsymbol : T_qsymbol",
"qsymbol : qsymbol '+' T_qsymbol",

};
#endif

int      yydebug;
int      yynerrs;

int      yyerrflag;
int      yychar;
YYSTYPE  yyval;
YYSTYPE  yylval;

/* define the initial stack-sizes */
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH  YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 10000
#define YYMAXDEPTH  10000
#endif
#endif

#define YYINITSTACKSIZE 200

typedef struct {
    unsigned stacksize;
    short    *s_base;
    short    *s_mark;
    short    *s_last;
    YYSTYPE  *l_base;
    YYSTYPE  *l_mark;
} YYSTACKDATA;
/* variables for the parser stack */
static YYSTACKDATA yystack;
#line 485 "../../lib/graph/parser.y"
#ifdef UNUSED
/* grammar allowing port variants */
/* at present, these are not used, so we remove them from the grammar */
/* NOTE: If used, these should be rewritten to take into account the */
/* move away from using ':' in the string and that symbols come from */
/* agstrdup and need to be freed. */
node_port	:	/* empty */
		|	port_location 
		|	port_angle 			/* undocumented */
		|	port_angle port_location 	/* undocumented */
		|	port_location port_angle 	/* undocumented */
		;

port_location	:	':' symbol {strcat(Port,":"); strcat(Port,$2);}
		|	':' '(' symbol {Symbol = strdup($3);} ',' symbol ')'
				{	char buf[SMALLBUF];
					sprintf(buf,":(%s,%s)",Symbol,$6);
					strcat(Port,buf); free(Symbol);
				}
		;

port_angle	:	'@' symbol
				{	char buf[SMALLBUF];
					sprintf(buf,"@%s",$2);
					strcat(Port,buf);
				}
		;

#endif
#line 649 "y.tab.c"

#if YYDEBUG
#include <stdio.h>		/* needed for printf */
#endif

#include <stdlib.h>	/* needed for malloc, etc */
#include <string.h>	/* needed for memset */

/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int yygrowstack(YYSTACKDATA *data)
{
    int i;
    unsigned newsize;
    short *newss;
    YYSTYPE *newvs;

    if ((newsize = data->stacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return -1;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;

    i = (int) (data->s_mark - data->s_base);
    newss = (short *)realloc(data->s_base, newsize * sizeof(*newss));
    if (newss == 0)
        return -1;

    data->s_base = newss;
    data->s_mark = newss + i;

    newvs = (YYSTYPE *)realloc(data->l_base, newsize * sizeof(*newvs));
    if (newvs == 0)
        return -1;

    data->l_base = newvs;
    data->l_mark = newvs + i;

    data->stacksize = newsize;
    data->s_last = data->s_base + newsize - 1;
    return 0;
}

#if YYPURE || defined(YY_NO_LEAKS)
static void yyfreestack(YYSTACKDATA *data)
{
    free(data->s_base);
    free(data->l_base);
    memset(data, 0, sizeof(*data));
}
#else
#define yyfreestack(data) /* nothing */
#endif

#define YYABORT  goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR  goto yyerrlab

int
YYPARSE_DECL()
{
    int yym, yyn, yystate;
#if YYDEBUG
    const char *yys;

    if ((yys = getenv("YYDEBUG")) != 0)
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = YYEMPTY;
    yystate = 0;

#if YYPURE
    memset(&yystack, 0, sizeof(yystack));
#endif

    if (yystack.s_base == NULL && yygrowstack(&yystack)) goto yyoverflow;
    yystack.s_mark = yystack.s_base;
    yystack.l_mark = yystack.l_base;
    yystate = 0;
    *yystack.s_mark = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = YYLEX) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = yyname[YYTRANSLATE(yychar)];
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack))
        {
            goto yyoverflow;
        }
        yystate = yytable[yyn];
        *++yystack.s_mark = yytable[yyn];
        *++yystack.l_mark = yylval;
        yychar = YYEMPTY;
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;

    yyerror("syntax error");

    goto yyerrlab;

yyerrlab:
    ++yynerrs;

yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yystack.s_mark]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yystack.s_mark, yytable[yyn]);
#endif
                if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack))
                {
                    goto yyoverflow;
                }
                yystate = yytable[yyn];
                *++yystack.s_mark = yytable[yyn];
                *++yystack.l_mark = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yystack.s_mark);
#endif
                if (yystack.s_mark <= yystack.s_base) goto yyabort;
                --yystack.s_mark;
                --yystack.l_mark;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = yyname[YYTRANSLATE(yychar)];
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = YYEMPTY;
        goto yyloop;
    }

yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    if (yym)
        yyval = yystack.l_mark[1-yym];
    else
        memset(&yyval, 0, sizeof yyval);
    switch (yyn)
    {
case 1:
#line 323 "../../lib/graph/parser.y"
	{begin_graph(yystack.l_mark[0].str); agstrfree(yystack.l_mark[0].str);}
break;
case 2:
#line 325 "../../lib/graph/parser.y"
	{AG.accepting_state = TRUE; end_graph();}
break;
case 3:
#line 327 "../../lib/graph/parser.y"
	{
					if (AG.parsed_g)
						agclose(AG.parsed_g);
					AG.parsed_g = NULL;
					/*exit(1);*/
				}
break;
case 4:
#line 333 "../../lib/graph/parser.y"
	{AG.parsed_g = NULL;}
break;
case 5:
#line 336 "../../lib/graph/parser.y"
	{yyval.str=yystack.l_mark[0].str;}
break;
case 6:
#line 336 "../../lib/graph/parser.y"
	{yyval.str=0;}
break;
case 7:
#line 340 "../../lib/graph/parser.y"
	{Agraph_type = AGRAPH; AG.edge_op = "--";}
break;
case 8:
#line 342 "../../lib/graph/parser.y"
	{Agraph_type = AGRAPHSTRICT; AG.edge_op = "--";}
break;
case 9:
#line 344 "../../lib/graph/parser.y"
	{Agraph_type = AGDIGRAPH; AG.edge_op = "->";}
break;
case 10:
#line 346 "../../lib/graph/parser.y"
	{Agraph_type = AGDIGRAPHSTRICT; AG.edge_op = "->";}
break;
case 11:
#line 350 "../../lib/graph/parser.y"
	{Current_class = TAG_GRAPH;}
break;
case 12:
#line 352 "../../lib/graph/parser.y"
	{Current_class = TAG_NODE; N = G->proto->n;}
break;
case 13:
#line 354 "../../lib/graph/parser.y"
	{Current_class = TAG_EDGE; E = G->proto->e;}
break;
case 22:
#line 376 "../../lib/graph/parser.y"
	{attr_set(yystack.l_mark[-2].str,yystack.l_mark[0].str); agstrfree(yystack.l_mark[-2].str); agstrfree(yystack.l_mark[0].str);}
break;
case 24:
#line 381 "../../lib/graph/parser.y"
	{attr_set(yystack.l_mark[0].str,"true"); agstrfree(yystack.l_mark[0].str); }
break;
case 31:
#line 394 "../../lib/graph/parser.y"
	{agerror("syntax error, statement skipped");}
break;
case 35:
#line 400 "../../lib/graph/parser.y"
	{}
break;
case 36:
#line 404 "../../lib/graph/parser.y"
	{Current_class = TAG_GRAPH; /* reset */}
break;
case 37:
#line 406 "../../lib/graph/parser.y"
	{Current_class = TAG_GRAPH;}
break;
case 38:
#line 410 "../../lib/graph/parser.y"
	{
					objport_t		rv;
					rv.obj = yystack.l_mark[-1].n;
					rv.port = Port;
					Port = NULL;
					yyval.obj = rv;
				}
break;
case 39:
#line 419 "../../lib/graph/parser.y"
	{yyval.n = bind_node(yystack.l_mark[0].str); agstrfree(yystack.l_mark[0].str);}
break;
case 41:
#line 423 "../../lib/graph/parser.y"
	{ Port=yystack.l_mark[0].str;}
break;
case 42:
#line 424 "../../lib/graph/parser.y"
	{Port=concat3(yystack.l_mark[-2].str,":",yystack.l_mark[0].str);agstrfree(yystack.l_mark[-2].str); agstrfree(yystack.l_mark[0].str);}
break;
case 43:
#line 428 "../../lib/graph/parser.y"
	{Current_class = TAG_NODE; N = (Agnode_t*)(yystack.l_mark[0].obj.obj);}
break;
case 44:
#line 430 "../../lib/graph/parser.y"
	{agstrfree(yystack.l_mark[-2].obj.port);Current_class = TAG_GRAPH; /* reset */}
break;
case 45:
#line 434 "../../lib/graph/parser.y"
	{begin_edgestmt(yystack.l_mark[0].obj);}
break;
case 46:
#line 436 "../../lib/graph/parser.y"
	{ E = SP->subg->proto->e;
				  Current_class = TAG_EDGE; }
break;
case 47:
#line 439 "../../lib/graph/parser.y"
	{end_edgestmt();}
break;
case 48:
#line 441 "../../lib/graph/parser.y"
	{begin_edgestmt(yystack.l_mark[0].obj);}
break;
case 49:
#line 443 "../../lib/graph/parser.y"
	{ E = SP->subg->proto->e;
				  Current_class = TAG_EDGE; }
break;
case 50:
#line 446 "../../lib/graph/parser.y"
	{end_edgestmt();}
break;
case 51:
#line 449 "../../lib/graph/parser.y"
	{mid_edgestmt(yystack.l_mark[0].obj);}
break;
case 52:
#line 451 "../../lib/graph/parser.y"
	{mid_edgestmt(yystack.l_mark[0].obj);}
break;
case 54:
#line 454 "../../lib/graph/parser.y"
	{mid_edgestmt(yystack.l_mark[0].obj);}
break;
case 55:
#line 456 "../../lib/graph/parser.y"
	{mid_edgestmt(yystack.l_mark[0].obj);}
break;
case 57:
#line 461 "../../lib/graph/parser.y"
	{yyval.obj = pop_gobj();}
break;
case 58:
#line 462 "../../lib/graph/parser.y"
	{ anonsubg(); }
break;
case 59:
#line 462 "../../lib/graph/parser.y"
	{yyval.obj = pop_gobj();}
break;
case 60:
#line 463 "../../lib/graph/parser.y"
	{ anonsubg(); }
break;
case 61:
#line 463 "../../lib/graph/parser.y"
	{yyval.obj = pop_gobj();}
break;
case 62:
#line 464 "../../lib/graph/parser.y"
	{subgraph_warn(); yyval.obj = pop_gobj();}
break;
case 63:
#line 468 "../../lib/graph/parser.y"
	{ Agraph_t	 *subg;
				if ((subg = agfindsubg(AG.parsed_g,yystack.l_mark[0].str))) aginsert(G,subg);
				else subg = agsubg(G,yystack.l_mark[0].str); 
				push_subg(subg);
				In_decl = FALSE;
				agstrfree(yystack.l_mark[0].str);
				}
break;
case 64:
#line 477 "../../lib/graph/parser.y"
	{yyval.str = yystack.l_mark[0].str; }
break;
case 65:
#line 478 "../../lib/graph/parser.y"
	{yyval.str = yystack.l_mark[0].str; }
break;
case 66:
#line 481 "../../lib/graph/parser.y"
	{yyval.str = yystack.l_mark[0].str; }
break;
case 67:
#line 482 "../../lib/graph/parser.y"
	{yyval.str = concat(yystack.l_mark[-2].str,yystack.l_mark[0].str); agstrfree(yystack.l_mark[-2].str); agstrfree(yystack.l_mark[0].str);}
break;
#line 1054 "y.tab.c"
    }
    yystack.s_mark -= yym;
    yystate = *yystack.s_mark;
    yystack.l_mark -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yystack.s_mark = YYFINAL;
        *++yystack.l_mark = yyval;
        if (yychar < 0)
        {
            if ((yychar = YYLEX) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = yyname[YYTRANSLATE(yychar)];
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yystack.s_mark, yystate);
#endif
    if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack))
    {
        goto yyoverflow;
    }
    *++yystack.s_mark = (short) yystate;
    *++yystack.l_mark = yyval;
    goto yyloop;

yyoverflow:
    yyerror("yacc stack overflow");

yyabort:
    yyfreestack(&yystack);
    return (1);

yyaccept:
    yyfreestack(&yystack);
    return (0);
}
