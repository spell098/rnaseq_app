![Travis Build Status](https://api.travis-ci.org/seandavi/GEOquery.svg?branch=master)

## Installation

To install from Bioconductor, use the following code:

```{r}
source("http://bioconductor.org/biocLite.R")
biocLite("GEOquery")
```

To install directly from github:

```{r}
library(devtools)
install_github('GEOquery','seandavi')
```
