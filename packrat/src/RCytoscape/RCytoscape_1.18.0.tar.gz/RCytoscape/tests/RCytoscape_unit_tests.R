print ("Automatic execution of RCytoscape unit tests disabled because they take too long for the build machine.")
#require("RCytoscape") || stop("unable to load RCytoscape package")
#RCytoscape:::.test()
