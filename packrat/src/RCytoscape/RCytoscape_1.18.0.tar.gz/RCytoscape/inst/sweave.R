Sweave ('RCytoscape.Rnw')
