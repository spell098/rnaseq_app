#.test <- function() BiocGenerics:::testPackage("RCytoscape")
.test <- function() print ("unit tests disabled")
