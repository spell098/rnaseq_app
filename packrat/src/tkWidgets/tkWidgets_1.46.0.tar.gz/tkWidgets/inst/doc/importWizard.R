### R code from vignette source 'importWizard.Rnw'

###################################################
### code chunk number 1: importWizard.Rnw:154-155
###################################################
toLatex(sessionInfo())


