/* Copyright Bioconductor Foundation NA, 2007, all rights reserved */
#include <R.h>
#include <Rinternals.h>

void gf_distance(double *x, double *kval, int *nr, int *nc, double *d, 
		 int *diag, int *method);
