library(XMLRPC)
# Doesn't work 
# xml.rpc('http://rpc.pingomatic.com/', 'weblogUpdates.ping', c('My Photoblog', 'http://www.my-site.com/photoblog/'))
